<?php

class Telegram {

    const CHAT_ID = 85199297;//آیدی عددی خود را جایگذاری کنید
    const TOKEN = '772157112:AAEpe5OJHHUBZvUFsbyu52RqmO19whsDpSo';//توکن خود را جایگذاری کنید

    public static function sendMessage($message)
    {
        $url = "https://api.telegram.org/bot" . self::TOKEN . "/sendMessage?chat_id=" . self::CHAT_ID;
        $url = $url . "&text=" . urlencode($message);
        $ch = curl_init();
        $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
        );
        curl_setopt_array($ch, $optArray);
        $result = curl_exec($ch);
        curl_close($ch);
    }

}
